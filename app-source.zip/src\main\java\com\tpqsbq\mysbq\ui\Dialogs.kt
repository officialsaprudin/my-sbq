package com.tpqsbq.mysbq.ui

import android.app.DatePickerDialog
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.tpqsbq.mysbq.model.Jurnal
import com.tpqsbq.mysbq.model.Santri
import com.tpqsbq.mysbq.model.ScanLogEntry
import com.tpqsbq.mysbq.util.AppUtils
import java.util.Calendar
import java.util.Locale

@Composable
fun SantriFormDialog(
    editingSantri: Santri?,
    availableClasses: List<String>,
    defaultClass: String,
    onDismiss: () -> Unit,
    onSave: (
        existingId: String?,
        nama: String,
        kelas: String,
        kehadiran: String,
        jilid: String,
        halaman: String,
        surah: String,
        ayat: String,
        nilaiHafalan: String,
        nilaiJilid: String,
        catatan: String
    ) -> Unit
) {
    val isEdit = editingSantri != null
    var nama by remember { mutableStateOf(editingSantri?.nama ?: "") }
    var kelas by remember {
        mutableStateOf(
            editingSantri?.kelas?.ifBlank { defaultClass } ?: defaultClass
        )
    }
    var isCustomKelas by remember { mutableStateOf(availableClasses.isEmpty()) }
    var kehadiran by remember { mutableStateOf(editingSantri?.kehadiran ?: "Hadir") }
    var jilid by remember { mutableStateOf(editingSantri?.jilid ?: "") }
    var halaman by remember { mutableStateOf(editingSantri?.halaman ?: "-") }
    var surah by remember { mutableStateOf(editingSantri?.surah ?: "-") }
    var ayat by remember { mutableStateOf(editingSantri?.ayat ?: "-") }
    var nilaiHafalan by remember {
        mutableStateOf(
            editingSantri?.nilaiHafalan?.ifBlank { editingSantri.keterangan.ifBlank { "Lancar" } } ?: "Lancar"
        )
    }
    var nilaiJilid by remember {
        mutableStateOf(
            editingSantri?.nilaiJilid?.ifBlank { editingSantri.keterangan.ifBlank { "Lancar" } } ?: "Lancar"
        )
    }
    var catatan by remember { mutableStateOf(editingSantri?.catatan ?: "") }

    val nilaiOptions = listOf("Lancar", "Kurang Lancar", "Mengulang", "-")
    val kehadiranOptions = listOf("Hadir", "Izin", "Sakit", "Alpa")

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 680.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndigoPrimary)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isEdit) "Update Progres Santri" else "Tambah Santri Baru",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                // Body
                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState())
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = nama,
                        onValueChange = { nama = it },
                        label = { Text("Nama Santri") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Kelas selector + option to type new class
                    if (!isCustomKelas && availableClasses.isNotEmpty()) {
                        DropdownSelector(
                            label = "Kelas / Rombel (Bisa Pindah Kelas)",
                            options = availableClasses,
                            selectedOption = kelas,
                            onOptionSelected = { kelas = it }
                        )
                        Text(
                            text = "+ Ketik Nama Kelas Baru",
                            color = IndigoPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { isCustomKelas = true }
                        )
                    } else {
                        OutlinedTextField(
                            value = kelas,
                            onValueChange = { kelas = it },
                            label = { Text("Nama Kelas / Rombel") },
                            placeholder = { Text("Cth: Kelas Madinah") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (availableClasses.isNotEmpty()) {
                            Text(
                                text = "Pilih dari Daftar Kelas yang Ada",
                                color = IndigoPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable {
                                    isCustomKelas = false
                                    if (kelas.isBlank()) kelas = availableClasses.first()
                                }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        DropdownSelector(
                            label = "Kehadiran",
                            options = kehadiranOptions,
                            selectedOption = kehadiran,
                            onOptionSelected = { kehadiran = it },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = jilid,
                            onValueChange = { jilid = it },
                            label = { Text("Posisi Jilid") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = halaman,
                            onValueChange = { halaman = it },
                            label = { Text("Halaman (Ngaji)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = surah,
                            onValueChange = { surah = it },
                            label = { Text("Surah Hafalan") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = ayat,
                            onValueChange = { ayat = it },
                            label = { Text("Ayat Hafalan Terakhir") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        DropdownSelector(
                            label = "Nilai Hafalan",
                            options = nilaiOptions,
                            selectedOption = nilaiHafalan,
                            onOptionSelected = { nilaiHafalan = it },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    DropdownSelector(
                        label = "Nilai Jilid / Ngaji",
                        options = nilaiOptions,
                        selectedOption = nilaiJilid,
                        onOptionSelected = { nilaiJilid = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = catatan,
                        onValueChange = { catatan = it },
                        label = { Text("Catatan Tambahan (Opsional)") },
                        placeholder = { Text("Cth: Tajwid kurang, Sering lupa huruf Dlod") },
                        minLines = 2,
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Batal", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                onSave(
                                    editingSantri?.id,
                                    nama,
                                    kelas,
                                    kehadiran,
                                    jilid,
                                    halaman,
                                    surah,
                                    ayat,
                                    nilaiHafalan,
                                    nilaiJilid,
                                    catatan
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Simpan Data", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryDialog(
    santri: Santri,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 620.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndigoPrimary)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Riwayat Ngaji: ${santri.nama}",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                if (santri.riwayat.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Belum ada riwayat ngaji", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(santri.riwayat) { r ->
                            Surface(
                                color = Color(0xFFF9FAFB),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = AppUtils.formatDateTimeShort(r.timestamp),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF4B5563)
                                        )
                                        StatusBadge(status = r.kehadiran)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Hafalan: ${r.surah} (${r.ayat})", fontSize = 12.sp)
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("H: ", fontSize = 10.sp, color = Color.Gray)
                                                NilaiBadge(ket = r.nilaiHafalan.ifBlank { r.keterangan })
                                            }
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Jilid: ${r.jilid} (Hal ${r.halaman})", fontSize = 12.sp)
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("J: ", fontSize = 10.sp, color = Color.Gray)
                                                NilaiBadge(ket = r.nilaiJilid.ifBlank { r.keterangan })
                                            }
                                        }
                                    }
                                    if (r.catatan.isNotBlank() && r.catatan != "-") {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Catatan: ${r.catatan}",
                                            fontSize = 11.sp,
                                            fontStyle = FontStyle.Italic,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BarcodeDialog(
    santri: Santri,
    onDismiss: () -> Unit,
    onPrintPdf: () -> Unit
) {
    val barcodeBmp = remember(santri.id) {
        AppUtils.generateBarcodeBitmap(santri.id, 600, 200)
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndigoPrimary)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ID Card Santri",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = santri.nama,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1F2937),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Image(
                        bitmap = barcodeBmp.asImageBitmap(),
                        contentDescription = "Barcode ${santri.id}",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Gunakan barcode ini untuk Absensi Scan",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }

                Surface(
                    color = Color(0xFFF9FAFB),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onPrintPdf,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Cetak Barcode (PDF)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun EditLembagaDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var name by remember { mutableStateOf(currentName) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndigoPrimary)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Edit Nama Lembaga",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                Column(modifier = Modifier.padding(18.dp)) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nama Lembaga (Dashboard)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Batal", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onSave(name) },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Simpan", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun JurnalDialog(
    kelas: String,
    initialDate: String,
    jurnalList: List<Jurnal>,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String) -> Unit
) {
    val context = LocalContext.current
    var tanggal by remember { mutableStateOf(initialDate) }

    val existing = remember(tanggal, kelas, jurnalList) {
        jurnalList.find { it.id == "${kelas}_${tanggal}" }
    }

    var tadarus by remember(existing) { mutableStateOf(existing?.tadarus ?: "") }
    var murojaah by remember(existing) { mutableStateOf(existing?.murojaah ?: "") }
    var materi by remember(existing) { mutableStateOf(existing?.materi ?: "") }

    fun pickDate() {
        val parts = tanggal.split("-")
        val cal = Calendar.getInstance()
        val yr = parts.getOrNull(0)?.toIntOrNull() ?: cal.get(Calendar.YEAR)
        val mo = (parts.getOrNull(1)?.toIntOrNull() ?: (cal.get(Calendar.MONTH) + 1)) - 1
        val dy = parts.getOrNull(2)?.toIntOrNull() ?: cal.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(context, { _, y, m, d ->
            tanggal = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
        }, yr, mo, dy).show()
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IndigoPrimary)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Jurnal Kelas: $kelas",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                Column(
                    modifier = Modifier
                        .padding(18.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { pickDate() },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Tanggal Jurnal", fontSize = 11.sp, color = Color.Gray)
                                Text(tanggal, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                            Icon(Icons.Default.CalendarToday, contentDescription = null, tint = IndigoPrimary)
                        }
                    }

                    OutlinedTextField(
                        value = tadarus,
                        onValueChange = { tadarus = it },
                        label = { Text("Tadarus Surah") },
                        placeholder = { Text("Cth: Al-Baqarah (1-10)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = murojaah,
                        onValueChange = { murojaah = it },
                        label = { Text("Murojaah (Surah & Ayat)") },
                        placeholder = { Text("Cth: An-Naba s/d An-Naziat") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = materi,
                        onValueChange = { materi = it },
                        label = { Text("Materi Pembelajaran") },
                        placeholder = { Text("Cth: Tajwid Hukum Nun Mati") },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Batal", color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onSave(kelas, tanggal, tadarus, murojaah, materi) },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Simpan Jurnal", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScannerDialog(
    scanLogs: List<ScanLogEntry>,
    onStartCameraScan: () -> Unit,
    onManualSubmit: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var manualId by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GreenSuccess)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Scan Barcode / QR Absensi",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                    }
                }

                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onStartCameraScan,
                        colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Buka Kamera Scanner Sekarang",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Input Manual Backup (Jika kartu lecek)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = manualId,
                            onValueChange = { manualId = it },
                            label = { Text("Atau Ketik ID Santri (Cth: ST123456)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                if (manualId.isNotBlank()) {
                                    onManualSubmit(manualId.trim())
                                    manualId = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Absen", fontWeight = FontWeight.Bold)
                        }
                    }

                    // Rapid-Scan Log History
                    Surface(
                        color = Color(0xFFF9FAFB),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "Log Scan Terakhir (Rapid-Scan):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            if (scanLogs.isEmpty()) {
                                Text(
                                    text = "Belum ada santri yang di-scan pada sesi ini.",
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    fontStyle = FontStyle.Italic
                                )
                            } else {
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    items(scanLogs) { log ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = GreenSuccess,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${log.nama} - Masuk (${log.timeStr})",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = Color(0xFF1F2937)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
