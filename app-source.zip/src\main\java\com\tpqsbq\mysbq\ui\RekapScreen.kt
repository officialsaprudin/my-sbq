package com.tpqsbq.mysbq.ui

import android.app.DatePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tpqsbq.mysbq.model.Jurnal
import com.tpqsbq.mysbq.model.RiwayatItem
import com.tpqsbq.mysbq.util.AppUtils
import com.tpqsbq.mysbq.viewmodel.AppUiState
import java.util.Calendar
import java.util.Locale

@Composable
fun RekapScreen(
    state: AppUiState,
    onKelasFilterChanged: (String) -> Unit,
    onDateRangeChanged: (String, String) -> Unit,
    onOpenJurnalModal: (String, String?) -> Unit,
    onExportGlobalPdf: () -> Unit
) {
    val context = LocalContext.current
    val filterOptions = remember(state.availableClasses) {
        listOf("Semua") + state.availableClasses
    }

    val kelasRenderList = remember(state.rekapKelasFilter, state.availableClasses) {
        if (state.rekapKelasFilter == "Semua") state.availableClasses else listOf(state.rekapKelasFilter)
    }

    fun showDatePicker(currentVal: String, onPicked: (String) -> Unit) {
        val parts = currentVal.split("-")
        val cal = Calendar.getInstance()
        val yr = parts.getOrNull(0)?.toIntOrNull() ?: cal.get(Calendar.YEAR)
        val mo = (parts.getOrNull(1)?.toIntOrNull() ?: (cal.get(Calendar.MONTH) + 1)) - 1
        val dy = parts.getOrNull(2)?.toIntOrNull() ?: cal.get(Calendar.DAY_OF_MONTH)

        DatePickerDialog(context, { _, y, m, d ->
            val formatted = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
            onPicked(formatted)
        }, yr, mo, dy).show()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF9FAFB))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header & Filters
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Laporan Progres Santri",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1F2937),
                        modifier = Modifier.weight(1f)
                    )

                    Button(
                        onClick = onExportGlobalPdf,
                        colors = ButtonDefaults.buttonColors(containerColor = RedDanger),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "Export Global PDF",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("PDF", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                DropdownSelector(
                    label = "Filter Kelas",
                    options = filterOptions,
                    selectedOption = state.rekapKelasFilter,
                    onOptionSelected = onKelasFilterChanged
                )

                // Date Range Pickers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    DateSelectCard(
                        label = "Dari Tanggal",
                        dateStr = state.rekapTglMulai,
                        onClick = {
                            showDatePicker(state.rekapTglMulai) { picked ->
                                onDateRangeChanged(picked, state.rekapTglAkhir)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                    DateSelectCard(
                        label = "Sampai Tanggal",
                        dateStr = state.rekapTglAkhir,
                        onClick = {
                            showDatePicker(state.rekapTglAkhir) { picked ->
                                onDateRangeChanged(state.rekapTglMulai, picked)
                            }
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (kelasRenderList.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Tidak ada kelas untuk ditampilkan.",
                        color = Color.Gray,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
        } else {
            items(kelasRenderList, key = { it }) { kls ->
                RekapKelasSection(
                    kelas = kls,
                    state = state,
                    onOpenJurnalModal = onOpenJurnalModal
                )
            }
        }
    }
}

@Composable
private fun DateSelectCard(
    label: String,
    dateStr: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedCard(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.outlinedCardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(label, fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                Text(dateStr, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF1F2937))
            }
            Icon(
                imageVector = Icons.Default.CalendarToday,
                contentDescription = null,
                tint = IndigoPrimary,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun RekapKelasSection(
    kelas: String,
    state: AppUiState,
    onOpenJurnalModal: (String, String?) -> Unit
) {
    val pengajar = state.pengajarMap[kelas] ?: "Belum diatur"
    val canEditJurnal = state.currentUser.role == "ustadz" && state.currentUser.kelas.contains(kelas)

    val jurnalKelasIni = remember(state.jurnalList, kelas, state.rekapTglMulai, state.rekapTglAkhir) {
        state.jurnalList
            .filter { it.kelas == kelas && it.tanggal >= state.rekapTglMulai && it.tanggal <= state.rekapTglAkhir }
            .sortedByDescending { it.tanggal }
    }

    data class SiaItem(val nama: String, val h: Int, val s: Int, val i: Int, val a: Int)
    data class ActivityItem(val nama: String, val riwayat: RiwayatItem)

    val siaList = mutableListOf<SiaItem>()
    val activityList = mutableListOf<ActivityItem>()

    state.santriList.filter { it.kelas == kelas }.forEach { s ->
        val rRange = s.riwayat.filter { r ->
            val t = r.timestamp.take(10)
            t >= state.rekapTglMulai && t <= state.rekapTglAkhir
        }
        if (rRange.isNotEmpty()) {
            var cH = 0
            var cS = 0
            var cI = 0
            var cA = 0
            rRange.forEach { r ->
                when (r.kehadiran) {
                    "Hadir" -> cH++
                    "Sakit" -> cS++
                    "Izin" -> cI++
                    "Alpa" -> cA++
                }
                activityList.add(ActivityItem(s.nama, r))
            }
            siaList.add(SiaItem(s.nama, cH, cS, cI, cA))
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Class Header
        Column {
            Text(
                text = kelas,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF1F2937)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = IndigoPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Pengajar: $pengajar",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = IndigoPrimary
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(top = 6.dp),
                thickness = 2.dp,
                color = Color(0xFFC7D2FE)
            )
        }

        // Jurnal Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = IndigoLight)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kumpulan Jurnal",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF374151)
                    )
                    if (canEditJurnal) {
                        Button(
                            onClick = { onOpenJurnalModal(kelas, null) },
                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Jurnal Hari Ini", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (jurnalKelasIni.isEmpty()) {
                    Text(
                        text = "Belum ada jurnal untuk rentang tanggal ini.",
                        fontSize = 13.sp,
                        color = IndigoPrimary,
                        fontStyle = FontStyle.Italic
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        jurnalKelasIni.forEach { j ->
                            JurnalItemCard(
                                jurnal = j,
                                canEdit = canEditJurnal,
                                onEdit = { onOpenJurnalModal(kelas, j.tanggal) }
                            )
                        }
                    }
                }
            }
        }

        // SIA Summary Card
        if (siaList.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Rekapitulasi Absensi",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF374151)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Table Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF3F4F6), RoundedCornerShape(6.dp))
                            .padding(vertical = 8.dp, horizontal = 8.dp)
                    ) {
                        Text("Nama Santri", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                        Text("H", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                        Text("S", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                        Text("I", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                        Text("A", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.weight(0.6f))
                    }

                    siaList.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp, horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.nama,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1F2937),
                                modifier = Modifier.weight(2f)
                            )
                            Text(
                                text = item.h.toString(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = GreenSuccess,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(0.6f)
                            )
                            Text(
                                text = item.s.toString(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = OrangeSick,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(0.6f)
                            )
                            Text(
                                text = item.i.toString(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = YellowWarn,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(0.6f)
                            )
                            Text(
                                text = item.a.toString(),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = RedDanger,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.weight(0.6f)
                            )
                        }
                        HorizontalDivider(color = Color(0xFFF3F4F6))
                    }
                }
            }
        }

        // Detailed Activity Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = "Rincian Progres Ngaji",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF374151)
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (activityList.isEmpty()) {
                    Text(
                        text = "Tidak ada data ngaji di rentang tanggal ini.",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        activityList.forEach { act ->
                            val r = act.riwayat
                            val tglCetak = AppUtils.formatDateSlashShort(r.timestamp)
                            Surface(
                                color = Color(0xFFF9FAFB),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = Color(0xFFE0E7FF),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text(
                                                    text = tglCetak,
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = IndigoPrimary,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = act.nama,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1F2937)
                                            )
                                        }
                                        StatusBadge(status = r.kehadiran)
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Hafalan: ${r.surah} (${r.ayat})",
                                                fontSize = 12.sp,
                                                color = Color(0xFF374151)
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("H: ", fontSize = 10.sp, color = Color.Gray)
                                                NilaiBadge(ket = r.nilaiHafalan.ifBlank { r.keterangan })
                                            }
                                        }
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "Jilid: ${r.jilid} (Hal ${r.halaman})",
                                                fontSize = 12.sp,
                                                color = Color(0xFF374151)
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("J: ", fontSize = 10.sp, color = Color.Gray)
                                                NilaiBadge(ket = r.nilaiJilid.ifBlank { r.keterangan })
                                            }
                                        }
                                    }

                                    if (r.catatan.isNotBlank() && r.catatan != "-") {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Catatan: ${r.catatan}",
                                            fontSize = 11.sp,
                                            fontStyle = FontStyle.Italic,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun JurnalItemCard(
    jurnal: Jurnal,
    canEdit: Boolean,
    onEdit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Jurnal Tgl: ${jurnal.tanggal}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = IndigoDark
                )
                if (canEdit) {
                    Surface(
                        color = IndigoPrimary,
                        shape = RoundedCornerShape(4.dp),
                        onClick = onEdit
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Isi/Edit Jurnal",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 8.dp),
                color = Color(0xFFF3F4F6)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                JurnalFieldBox("Tadarus", jurnal.tadarus, Modifier.weight(1f))
                JurnalFieldBox("Murojaah", jurnal.murojaah, Modifier.weight(1f))
                JurnalFieldBox("Materi", jurnal.materi, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun JurnalFieldBox(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        color = Color(0xFFF9FAFB),
        shape = RoundedCornerShape(6.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = IndigoPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value.ifBlank { "-" },
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF1F2937)
            )
        }
    }
}
